import { api } from "./api";

export type PropertyQuery = {
  page: number;
  search?: string;
  categoryId?: number;
  sortBy?: "name" | "price";
  sortOrder?: "asc" | "desc";
  latitude?: number;
  longitude?: number;
};

export async function getProperties(params: PropertyQuery) {
  const res = await api.get("/properties", { params });
  return res.data;
}

export const propertyCatalogService = {
  getDetail: (id: number) =>
    api.get(`/properties/${id}`),
};