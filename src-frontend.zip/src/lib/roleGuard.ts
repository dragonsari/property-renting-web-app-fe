import { useEffect } from "react";
import { useAuthStore } from "@/stores/auth.store";

type Role = "USER" | "TENANT";

export function useRoleGuard(requiredRole: Role) {
  const role = useAuthStore((s) => s.role);

  useEffect(() => {
    if (!role || role !== requiredRole) {
      window.location.href = "/";
    }
  }, [role, requiredRole]);
}
