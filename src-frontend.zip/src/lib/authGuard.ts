import { useEffect } from "react";
import { useAuthStore } from "@/stores/auth.store";

export function useAuthGuard() {
  const token = useAuthStore((s) => s.token);

  useEffect(() => {
    if (!token) {
      window.location.href = "/";
    }
  }, [token]);
}
