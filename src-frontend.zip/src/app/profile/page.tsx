// import ProfileView from "@/views/Profile/page";

// export default function Page() {
//   return <ProfileView />;
// }

import ProfileUIOnly from "@/views/Profile/page";

export default function Page(){
  return<ProfileUIOnly/>
}
