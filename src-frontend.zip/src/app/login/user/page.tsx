import LoginPage from "@/views/Login/login";
export default function UserLoginPage(){
    return <LoginPage role="USER"/>
}