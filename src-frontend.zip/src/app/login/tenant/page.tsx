import LoginPage from "@/views/Login/login";
export default function TenantLoginPage(){
    return <LoginPage role="TENANT"/>
}