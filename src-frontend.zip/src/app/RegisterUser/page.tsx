import RegisterUserPage from "@/views/Register/user/page";

export default function RegisterView(){
    return <RegisterUserPage/>;
}