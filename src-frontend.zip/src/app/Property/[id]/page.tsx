// import PropertyPublicDetailView from "@/views/PropertyPublicDetail/page";

// export default function Page({ params }: { params: { id: string } }) {
//   return <PropertyPublicDetailView propertyId={Number(params.id)} />;
// }


import PropertyPublicDetailUI from "@/views/PropertyPublicDetail/page";

export default function PropertyDetailPage() {
  return <div className="mx-auto max-w-4xl"><PropertyPublicDetailUI /></div>
}
