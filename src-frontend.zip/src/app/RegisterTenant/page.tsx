import RegisterTenantPage from "@/views/Register/tenant/page"

export default function RegisterView(){
    return <RegisterTenantPage/>
}