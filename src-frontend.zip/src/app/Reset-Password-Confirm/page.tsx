import ForgotPasswordPageConfirm from "@/views/ResetPassword/components/Confirm";

export default function Page() {
  return <ForgotPasswordPageConfirm />;
}
