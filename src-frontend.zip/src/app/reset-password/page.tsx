import ForgotPasswordPageRequest from "@/views/ResetPassword/components/Request";

export default function Page() {
  return <ForgotPasswordPageRequest/>;
}
