// import TenantPropertiesView from "@/views/TenantProperties/page";

// export default function Page() {
//   return <TenantPropertiesView />;
// }

import TenantPropertiesUI from "@/views/TenantProperties/page";

export default function TenantPropertiesPage() {
  return <div className="mx-auto max-w-3xl">
    <TenantPropertiesUI />;  
  </div>
  
}
