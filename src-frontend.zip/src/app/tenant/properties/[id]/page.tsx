// import RoomManagementView from "@/views/RoomManagement/page";

// export default function Page({ params }: { params: { id: string } }) {
//   return <RoomManagementView propertyId={Number(params.id)} />;
// }

import RoomManagementUI from "@/views/RoomManagement/page";

export default function TenantRoomPage() {
  return <div className="mx-auto max-w-3xl"><RoomManagementUI />;</div>
  
}
