// import RoomCalendarView from "@/views/RoomCalender/page";

// export default function Page({ params }: { params: { roomId: string } }) {
//   return <RoomCalendarView roomId={Number(params.roomId)} />;
// }

import RoomCalendarUI from "@/views/RoomCalender/page";

export default function RoomCalendarPage() {
  return <div className="mx-auto max-w-3xl"><RoomCalendarUI /></div>
}
