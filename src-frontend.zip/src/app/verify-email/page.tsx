import VerifyEmailView from "@/views/verify-email/page";

export default function VerifyEmailPage (){
    return <VerifyEmailView/>
}