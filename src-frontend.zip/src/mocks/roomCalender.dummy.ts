export const DUMMY_PEAK_RATES = [
  {
    id: 1,
    startDate: "2026-02-10",
    endDate: "2026-02-15",
    type: "PERCENT",
    value: 20,
  },
  {
    id: 2,
    startDate: "2026-02-20",
    endDate: "2026-02-22",
    type: "NOMINAL",
    value: 200000,
  },
];
