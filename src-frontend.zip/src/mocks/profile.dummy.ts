export const DUMMY_PROFILE = {
  name: "Ammar Nashirudin",
  email: "ammar@mail.com",
  isVerified: false,
  message: "Ini hanya tampilan UI",
};
