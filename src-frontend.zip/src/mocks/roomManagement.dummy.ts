export const DUMMY_ROOMS = [
  {
    id: 1,
    name: "Deluxe Room",
    basePrice: 850000,
  },
  {
    id: 2,
    name: "Family Room",
    basePrice: 1200000,
  },
  {
    id: 3,
    name: "Standard Room",
    basePrice: 600000,
  },
];
