export const DUMMY_PROPERTY_PUBLIC_DETAIL = {
  id: 1,
  name: "Villa Sunset Bali",
  description:
    "Villa dengan pemandangan laut, cocok untuk liburan keluarga dan pasangan.",
  image:
    "https://images.unsplash.com/photo-1505691938895-1758d7feb511",

  rooms: [
    {
      id: 1,
      name: "Deluxe Room",
      description: "King bed, AC, WiFi",
      basePrice: 850000,
    },
    {
      id: 2,
      name: "Family Room",
      description: "2 Queen bed, AC, WiFi",
      basePrice: 1200000,
    },
  ],

  calendar: [
    { date: "02", price: 850000 },
    { date: "03", price: 850000 },
    { date: "04", price: null },
    { date: "05", price: 900000 },
    { date: "06", price: null },
    { date: "07", price: 850000 },
  ],
};
