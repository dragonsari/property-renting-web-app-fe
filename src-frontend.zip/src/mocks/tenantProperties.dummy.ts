export const DUMMY_TENANT_PROPERTIES = [
  {
    id: 1,
    name: "Villa Sunset Bali",
    category: "Villa",
    city: "Bali",
    totalRooms: 5,
    lowestPrice: 850000,
  },
  {
    id: 2,
    name: "Hotel City Jakarta",
    category: "Hotel",
    city: "Jakarta",
    totalRooms: 12,
    lowestPrice: 650000,
  },
  {
    id: 3,
    name: "Apartment Cozy Bandung",
    category: "Apartment",
    city: "Bandung",
    totalRooms: 3,
    lowestPrice: 500000,
  },
];
