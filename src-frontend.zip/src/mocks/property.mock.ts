export type DummyProperty = {
  id: number;
  name: string;
  image: string;
  category: { name: string };
  lowestPrice: number;
};

export const DUMMY_PROPERTIES: DummyProperty[] = [
  {
    id: 1,
    name: "Villa Sunset Bali",
    image:
      "https://images.unsplash.com/photo-1505691938895-1758d7feb511",
    category: { name: "Villa" },
    lowestPrice: 850000,
  },
  {
    id: 2,
    name: "Hotel City Jakarta",
    image:
      "https://images.unsplash.com/photo-1566073771259-6a8506099945",
    category: { name: "Hotel" },
    lowestPrice: 650000,
  },
  {
    id: 3,
    name: "Apartment Cozy Bandung",
    image:
      "https://images.unsplash.com/photo-1502673530728-f79b4cab31b1",
    category: { name: "Apartment" },
    lowestPrice: 500000,
  },
];
