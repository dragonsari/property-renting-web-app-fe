import { useEffect, useState } from "react";
import { propertyManagementService } from "@/services/propertyManagement.service";

export function useTenantProperties() {
  const [data, setData] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  function fetchData() {
    propertyManagementService
      .getMyProperties()
      .then((res) => setData(res.data))
      .finally(() => setLoading(false));
  }

  useEffect(fetchData, []);

  return { data, loading, refetch: fetchData };
}
