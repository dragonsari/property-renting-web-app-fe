import { useEffect, useState } from "react";
import { getProperties, PropertyQuery } from "@/services/propertyCatalog.service";

export function usePropertyCatalog(query: PropertyQuery) {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchData();
  }, [JSON.stringify(query)]);

  async function fetchData() {
    setLoading(true);
    const res = await getProperties(query);
    setData(res);
    setLoading(false);
  }

  return { data, loading };
}
