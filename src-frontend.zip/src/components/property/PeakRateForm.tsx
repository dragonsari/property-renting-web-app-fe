// "use client";

// import { useState } from "react";
// import { useRoomCalendar } from "@/hooks/useRoomCalender";
// import { Button } from "@/components/ui/button";
// import { Input } from "@/components/ui/input";

// export default function PeakRateForm({
//   roomId,
// }: {
//   roomId: number;
// }) {
//   const { createPeak } = useRoomCalendar();
//   const [form, setForm] = useState({
//     startDate: "",
//     endDate: "",
//     type: "PERCENT",
//     value: "",
//   });

//   async function submit() {
//     if (!form.startDate || !form.endDate || !form.value) {
//       alert("Semua field wajib diisi");
//       return;
//     }

//     await createPeak(roomId, {
//       ...form,
//       value: Number(form.value),
//     });

//     alert("Peak rate added");
//   }

//   return (
//     <div className="border p-4 rounded-lg space-y-3">
//       <h2 className="font-medium">Peak Season Rate</h2>

//       <Input
//         type="date"
//         onChange={(e) => setForm({ ...form, startDate: e.target.value })}
//       />

//       <Input
//         type="date"
//         onChange={(e) => setForm({ ...form, endDate: e.target.value })}
//       />

//       <select
//         className="border rounded px-2 py-1"
//         onChange={(e) => setForm({ ...form, type: e.target.value })}
//       >
//         <option value="PERCENT">Percent (%)</option>
//         <option value="NOMINAL">Nominal</option>
//       </select>

//       <Input
//         placeholder="Value"
//         type="number"
//         onChange={(e) => setForm({ ...form, value: e.target.value })}
//       />

//       <Button onClick={submit}>Save</Button>
//     </div>
//   );
// }

"use client";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export default function PeakRateFormUI() {
  return (
    <div className="border p-4 rounded-lg space-y-3">
      <h2 className="font-medium">
        Peak Season Rate
      </h2>

      <Input type="date" placeholder="Start date" />
      <Input type="date" placeholder="End date" />

      <select className="border rounded px-2 py-1 w-full">
        <option>Percent (%)</option>
        <option>Nominal</option>
      </select>

      <Input
        type="number"
        placeholder="Value"
      />

      <Button>
        Save
      </Button>
    </div>
  );
}

