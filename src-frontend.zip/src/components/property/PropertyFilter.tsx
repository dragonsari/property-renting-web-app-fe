"use client";

import { Button } from "../ui/button";
import DestinationInput from "../search/DestinationInput";
import { useState } from "react";

type SearchPayload = {
  latitude: number;
  longitude: number;
};

type Props = {
  onChange: (key: string, value: any) => void;
  onSearch: (payload: SearchPayload) => void;
};

export default function PropertyFilter({ onChange, onSearch }: Props) {
  const [destination, setDestination] = useState<{
    label: string;
    latitude: number;
    longitude: number;
  } | null>(null);

  function submit() {
    if (!destination) {
      alert("Pilih destinasi terlebih dahulu");
      return;
    }

    onSearch({
      latitude: destination.latitude,
      longitude: destination.longitude,
    });
  }

  return (
    <div>

      <div className="relative h-full flex items-center justify-center mb-4 shadow-xl rounded-3xl">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            submit();
          }}
          className="bg-white p-6 rounded-xl w-full max-w-4xl grid grid-cols-1 md:grid-cols-4 gap-4"
        >
          <DestinationInput onSelect={setDestination} />

          <input type="date" className="border rounded px-3 py-2" />
          <input type="date" className="border rounded px-3 py-2" />

          <Button type="submit" className="w-full bg-blue-600">
            Cari
          </Button>
        </form>
      </div>


      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <input
          placeholder="Search property..."
          className="border rounded px-3 py-2"
          onChange={(e) => onChange("search", e.target.value)}
        />

        <select
          className="border rounded px-3 py-2"
          onChange={(e) => onChange("sortBy", e.target.value)}
        >
          <option value="name">Name</option>
          <option value="price">Price</option>
        </select>

        <select
          className="border rounded px-3 py-2"
          onChange={(e) => onChange("sortOrder", e.target.value)}
        >
          <option value="asc">Asc</option>
          <option value="desc">Desc</option>
        </select>
      </div>
    </div>
  );
}


// "use client";

// import { Button } from "../ui/button";
// import DestinationInput from "../search/DestinationInput";

// export default function PropertyFilter() {
//   return (
//     <div className="space-y-6">
//       {/* ===== LOCATION SEARCH UI ONLY ===== */}
//       <div className="relative h-full flex items-center justify-center mb-4 shadow-xl rounded-3xl">
//         <div className="bg-white p-6 rounded-xl w-full max-w-4xl grid grid-cols-1 md:grid-cols-4 gap-4">
//           {/* REQUIRED PROP — DUMMY */}
//           <DestinationInput onSelect={() => {}} />

//           <input
//             type="date"
//             className="border rounded px-3 py-2"
//           />
//           <input
//             type="date"
//             className="border rounded px-3 py-2"
//           />

//           <Button type="button" className="w-full bg-blue-600">
//             Cari
//           </Button>
//         </div>
//       </div>

//       {/* ===== FILTER UI ONLY ===== */}
//       <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
//         <input
//           placeholder="Search property..."
//           className="border rounded px-3 py-2"
//         />

//         <select className="border rounded px-3 py-2">
//           <option value="name">Name</option>
//           <option value="price">Price</option>
//         </select>

//         <select className="border rounded px-3 py-2">
//           <option value="asc">Asc</option>
//           <option value="desc">Desc</option>
//         </select>
//       </div>
//     </div>
//   );
// }
