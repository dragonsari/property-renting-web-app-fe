// import DeletePropertyDialog from "./DeletePropertyDialog";

// export default function PropertyTable({
//   properties,
//   onDeleted,
// }: {
//   properties: any[];
//   onDeleted: () => void;
// }) {
//   return (
//     <div className="border rounded-lg overflow-hidden">
//       <table className="w-full text-sm">
//         <thead className="bg-muted">
//           <tr>
//             <th className="p-3 text-left">Name</th>
//             <th className="p-3">Category</th>
//             <th className="p-3">Rooms</th>
//             <th className="p-3">Actions</th>
//           </tr>
//         </thead>

//         <tbody>
//           {properties.map((p) => (
//             <tr key={p.id} className="border-t">
//               <td className="p-3">{p.name}</td>
//               <td className="p-3">{p.category?.name}</td>
//               <td className="p-3 text-center">{p.rooms?.length || 0}</td>
//               <td className="p-3 space-x-2">
//                 <a
//                   href={`/tenant/properties/${p.id}`}
//                   className="text-blue-600"
//                 >
//                   Edit
//                 </a>

//                 <DeletePropertyDialog
//                   propertyId={p.id}
//                   onSuccess={onDeleted}
//                 />
//               </td>
//             </tr>
//           ))}
//         </tbody>
//       </table>
//     </div>
//   );
// }


"use client";

type Property = {
  id: number;
  name: string;
  category: string;
  city: string;
  totalRooms: number;
  lowestPrice: number;
};

type Props = {
  properties: Property[];
};

export default function PropertyTableUI({ properties }: Props) {
  return (
    <div className="border rounded-lg overflow-hidden">
      <table className="w-full text-sm">
        <thead className="bg-muted">
          <tr>
            <th className="p-3 text-left">Name</th>
            <th className="p-3">Category</th>
            <th className="p-3">City</th>
            <th className="p-3">Rooms</th>
            <th className="p-3">Lowest Price</th>
            <th className="p-3">Actions</th>
          </tr>
        </thead>

        <tbody>
          {properties.map((p) => (
            <tr key={p.id} className="border-t">
              <td className="p-3">{p.name}</td>
              <td className="p-3 text-center">{p.category}</td>
              <td className="p-3 text-center">{p.city}</td>
              <td className="p-3 text-center">{p.totalRooms}</td>
              <td className="p-3">
                IDR {p.lowestPrice.toLocaleString()}
              </td>
              <td className="p-3 space-x-2 text-center">
                <span className="text-blue-600 cursor-pointer">
                  Edit
                </span>
                <span className="text-red-600 cursor-pointer">
                  Delete
                </span>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
