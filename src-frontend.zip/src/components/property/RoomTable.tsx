// import DeleteRoomDialog from "./DeleteRoomDialog";
// import { useEffect, useState } from "react";
// import { api } from "@/services/api";

// export default function RoomTable({
//   propertyId,
//   refreshKey,
// }: {
//   propertyId: number;
//   refreshKey: number;
// }) {
//   const [rooms, setRooms] = useState<any[]>([]);

//   useEffect(() => {
//     api
//       .get(`/properties/${propertyId}`)
//       .then((res) => setRooms(res.data.rooms));
//   }, [propertyId, refreshKey]);

//   return (
//     <div className="border rounded-lg">
//       <table className="w-full text-sm">
//         <thead className="bg-muted">
//           <tr>
//             <th className="p-3">Room</th>
//             <th className="p-3">Price</th>
//             <th className="p-3">Actions</th>
//           </tr>
//         </thead>

//         <tbody>
//           {rooms.map((r) => (
//             <tr key={r.id} className="border-t">
//               <td className="p-3">{r.name}</td>
//               <td className="p-3">
//                 IDR {r.basePrice.toLocaleString()}
//               </td>
//               <td className="p-3">
//                 <DeleteRoomDialog roomId={r.id} />
//               </td>
//             </tr>
//           ))}
//         </tbody>
//       </table>
//     </div>
//   );
// }

"use client";

import { DUMMY_ROOMS } from "@/mocks/roomManagement.dummy";

export default function RoomTableUI() {
  return (
    <div className="border rounded-lg overflow-hidden">
      <table className="w-full text-sm">
        <thead className="bg-muted">
          <tr>
            <th className="p-3 text-left">Room</th>
            <th className="p-3">Price</th>
            <th className="p-3">Actions</th>
          </tr>
        </thead>

        <tbody>
          {DUMMY_ROOMS.map((room) => (
            <tr key={room.id} className="border-t">
              <td className="p-3">{room.name}</td>
              <td className="p-3">
                IDR {room.basePrice.toLocaleString()}
              </td>
              <td className="p-3 space-x-2">
                <span className="text-blue-600 cursor-pointer">
                  Edit
                </span>
                <span className="text-red-600 cursor-pointer">
                  Delete
                </span>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
