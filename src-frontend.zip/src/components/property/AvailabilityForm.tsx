// "use client";

// import { useState } from "react";
// import { useRoomCalendar } from "@/hooks/useRoomCalender";
// import { Button } from "@/components/ui/button";
// import { Input } from "@/components/ui/input";

// export default function AvailabilityForm({
//   roomId,
// }: {
//   roomId: number;
// }) {
//   const { setAvailability } = useRoomCalendar();
//   const [date, setDate] = useState("");
//   const [available, setAvailable] = useState(true);

//   async function submit() {
//     if (!date) return alert("Tanggal wajib diisi");

//     await setAvailability(roomId, {
//       date,
//       isAvailable: available,
//     });

//     alert("Availability updated");
//   }

//   return (
//     <div className="border p-4 rounded-lg space-y-3">
//       <h2 className="font-medium">Room Availability</h2>

//       <Input
//         type="date"
//         value={date}
//         onChange={(e) => setDate(e.target.value)}
//       />

//       <select
//         className="border rounded px-2 py-1"
//         onChange={(e) => setAvailable(e.target.value === "true")}
//       >
//         <option value="true">Available</option>
//         <option value="false">Unavailable</option>
//       </select>

//       <Button onClick={submit}>Apply</Button>
//     </div>
//   );
// }

"use client";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export default function AvailabilityFormUI() {
  return (
    <div className="border p-4 rounded-lg space-y-3">
      <h2 className="font-medium">
        Room Availability
      </h2>

      <Input type="date" />

      <select className="border rounded px-2 py-1 w-full">
        <option>Available</option>
        <option>Unavailable</option>
      </select>

      <Button>
        Apply
      </Button>
    </div>
  );
}
