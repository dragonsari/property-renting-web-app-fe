// "use client";

// import { useEffect, useState } from "react";
// import { api } from "@/services/api";
// import { useRoomCalendar } from "@/hooks/useRoomCalender";

// export default function PeakRateTable({ roomId }: { roomId: number }) {
//   const [peaks, setPeaks] = useState<any[]>([]);
//   const { deletePeak } = useRoomCalendar();

//   useEffect(() => {
//     api.get(`/properties`).then(() => {}); 
//   }, []);

//   async function remove(id: number) {
//     if (!confirm("Hapus peak rate ini?")) return;
//     await deletePeak(id);
//     setPeaks((p) => p.filter((x) => x.id !== id));
//   }

//   return (
//     <div className="border rounded-lg">
//       <table className="w-full text-sm">
//         <thead>
//           <tr>
//             <th className="p-2">Range</th>
//             <th className="p-2">Type</th>
//             <th className="p-2">Value</th>
//             <th className="p-2">Action</th>
//           </tr>
//         </thead>
//         <tbody>
//           {peaks.map((p) => (
//             <tr key={p.id}>
//               <td className="p-2">
//                 {p.startDate} - {p.endDate}
//               </td>
//               <td className="p-2">{p.type}</td>
//               <td className="p-2">{p.value}</td>
//               <td className="p-2">
//                 <button
//                   onClick={() => remove(p.id)}
//                   className="text-red-600"
//                 >
//                   Delete
//                 </button>
//               </td>
//             </tr>
//           ))}
//         </tbody>
//       </table>
//     </div>
//   );
// }

"use client";

import { DUMMY_PEAK_RATES } from "@/mocks/roomCalender.dummy";

export default function PeakRateTableUI() {
  return (
    <div className="border rounded-lg overflow-hidden">
      <table className="w-full text-sm">
        <thead className="bg-muted">
          <tr>
            <th className="p-2">Range</th>
            <th className="p-2">Type</th>
            <th className="p-2">Value</th>
            <th className="p-2">Action</th>
          </tr>
        </thead>

        <tbody>
          {DUMMY_PEAK_RATES.map((p) => (
            <tr key={p.id} className="border-t">
              <td className="p-2">
                {p.startDate} – {p.endDate}
              </td>
              <td className="p-2 text-center">
                {p.type}
              </td>
              <td className="p-2 text-center">
                {p.type === "PERCENT"
                  ? `${p.value}%`
                  : `IDR ${p.value.toLocaleString()}`
                }
              </td>
              <td className="p-2 text-center">
                <span className="text-red-600 cursor-pointer">
                  Delete
                </span>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
