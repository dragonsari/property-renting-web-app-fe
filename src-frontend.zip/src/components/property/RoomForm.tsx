// "use client";

// import { useState } from "react";
// import { useRooms } from "@/hooks/useRooms";
// import { Button } from "@/components/ui/button";
// import { Input } from "@/components/ui/input";

// export default function RoomForm({
//   propertyId,
//   onSuccess,
// }: {
//   propertyId: number;
//   onSuccess: () => void;
// }) {
//   const { create, loading } = useRooms();
//   const [form, setForm] = useState({
//     name: "",
//     description: "",
//     basePrice: "",
//   });

//   async function submit() {
//     if (!form.name || !form.basePrice) {
//       alert("Room name & price wajib diisi");
//       return;
//     }

//     await create(propertyId, {
//       ...form,
//       basePrice: Number(form.basePrice),
//     });

//     setForm({ name: "", description: "", basePrice: "" });
//     onSuccess();
//   }

//   return (
//     <div className="border p-4 rounded-lg space-y-3">
//       <h2 className="font-medium">Add Room</h2>

//       <Input
//         placeholder="Room name"
//         value={form.name}
//         onChange={(e) => setForm({ ...form, name: e.target.value })}
//       />

//       <Input
//         placeholder="Price"
//         type="number"
//         value={form.basePrice}
//         onChange={(e) => setForm({ ...form, basePrice: e.target.value })}
//       />

//       <Input
//         placeholder="Description"
//         value={form.description}
//         onChange={(e) =>
//           setForm({ ...form, description: e.target.value })
//         }
//       />

//       <Button onClick={submit} disabled={loading}>
//         Save
//       </Button>
//     </div>
//   );
// }

"use client";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export default function RoomFormUI() {
  return (
    <div className="border p-4 rounded-lg space-y-3">
      <h2 className="font-medium">Add Room</h2>

      <Input placeholder="Room name" />
      <Input placeholder="Price" type="number" />
      <Input placeholder="Description" />

      <Button>
        Save
      </Button>
    </div>
  );
}