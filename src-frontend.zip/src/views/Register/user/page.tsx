"use client";

import { useState } from "react";
import Link from "next/link";

import { LogoIcon } from "@/components/logo";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useRegister } from "@/hooks/useRegister";
import SocialLogin from "@/components/auth/SocialLogin";


export default function RegisterUserPage() {
  const [email, setEmail] = useState("");
  const { registerUser, loading, error } = useRegister();

  const onSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    await registerUser(email);
  };

  return (
    <section
      className="flex min-h-screen bg-zinc-50 px-4 py-16 md:py-32 dark:bg-transparent"
      id="register"
    >
      <form
        onSubmit={onSubmit}
        className="bg-card m-auto h-fit w-full max-w-sm rounded-[calc(var(--radius)+.125rem)] border p-0.5 shadow-md"
      >
        <div className="p-8 pb-6">
          <div>
            <Link href="/" aria-label="go home">
              <LogoIcon />
            </Link>

            <h1 className="mb-1 mt-4 text-xl font-semibold">
              Create a Property renting account
            </h1>
            <p className="text-sm">
              Welcome! Create an account to get started
            </p>
          </div>

        
          <div className="mt-6">
            <SocialLogin role="USER" />
          </div>

          <hr className="my-4 border-dashed" />


          <div className="space-y-5">
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>

            {error && (
              <p className="text-center text-sm text-red-500">
                {error}
              </p>
            )}

            <Button className="w-full" disabled={loading}>
              {loading ? "Processing..." : "Continue"}
            </Button>
          </div>
        </div>

        <div className="bg-muted border p-3">
          <p className="text-center text-sm">
            Have an account?
            <Button asChild type="submit" variant="link" className="px-2">
              <Link href="/login/user">Sign In</Link>
            </Button>
          </p>

          <p className="text-center text-sm">
            Sign Up as?
            <Button asChild variant="link" className="px-2">
              <Link href="/RegisterTenant">Tenant</Link>
            </Button>
          </p>
        </div>
      </form>
    </section>
  );
}
