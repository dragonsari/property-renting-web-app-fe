"use client";

import { usePropertyPublicDetail } from "@/hooks/usePropertyPublicDetail";
import RoomPriceList from "@/components/property/RoomPriceList";
import PriceCalendar from "@/components/property/PriceCalender";

export default function PropertyPublicDetailView({
  propertyId,
}: {
  propertyId: number;
}) {
  const { data, loading } = usePropertyPublicDetail(propertyId);

  if (loading) return <p>Loading...</p>;
  if (!data) return <p>Property not found</p>;

  return (
    <div className="p-6 space-y-6">
      <img
        src={data.image}
        className="w-full h-72 object-cover rounded-xl"
      />

      <div>
        <h1 className="text-2xl font-semibold">{data.name}</h1>
        <p className="text-muted-foreground">{data.description}</p>
      </div>

      <RoomPriceList rooms={data.rooms} />

      <PriceCalendar rooms={data.rooms} />
    </div>
  );
}


// "use client";

// import RoomPriceListUI from "@/components/property/RoomPriceList";
// import PriceCalendarUI from "@/components/property/PriceCalender";
// import { DUMMY_PROPERTY_PUBLIC_DETAIL } from "@/mocks/propertyPublicDetail.mock";

// export default function PropertyPublicDetailUI() {
//   const data = DUMMY_PROPERTY_PUBLIC_DETAIL;

//   return (
//     <div className="p-6 space-y-6 mt-16">
//       <img
//         src={data.image}
//         className="w-full h-72 object-cover rounded-xl"
//       />

//       <div>
//         <h1 className="text-2xl font-semibold">
//           {data.name}
//         </h1>
//         <p className="text-muted-foreground">
//           {data.description}
//         </p>
//       </div>

//       <RoomPriceListUI rooms={data.rooms} />
//       <PriceCalendarUI calendar={data.calendar} />
//     </div>
//   );
// }
