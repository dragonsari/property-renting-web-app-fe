"use client";

import { useProfile } from "@/hooks/useProfile";
import { useAuthGuard } from "@/lib/authGuard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useState } from "react";

export default function ProfileView() {
  useAuthGuard();

  const {
    profile,
    updateProfile,
    updateEmail,
    resendVerification,
    updatePassword,
    message,
    
  } = useProfile();

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  if (!profile) return <p>Loading...</p>;

  return (
    <div className="mx-auto mt-16 max-w-md space-y-4">
      <h1 className="text-xl font-semibold">My Profile</h1>

      {!profile.isVerified && (
        <div className="rounded bg-yellow-100 p-3 text-sm">
          Email belum terverifikasi
          <Button
            size="sm"
            variant="link"
            onClick={resendVerification}
          >
            Kirim ulang verifikasi
          </Button>
        </div>
      )}

    
      <Input
        placeholder="Name"
        defaultValue={profile.name}
        onChange={(e) => setName(e.target.value)}
      />

      <Input
        type="file"
        accept=".jpg,.jpeg,.png,.gif"
        onChange={(e) => setFile(e.target.files?.[0] || null)}
      />

      <Button onClick={() => updateProfile(name, file ?? undefined)}>
        Update Profile
      </Button>

    
      <Input
        placeholder="New Email"
        onChange={(e) => setEmail(e.target.value)}
      />
      <Button variant="outline" onClick={() => updateEmail(email)}>
        Update Email
      </Button>
      <Input
        type="password"
        placeholder="Current Password"
        onChange={(e) => setCurrentPassword(e.target.value)}
      />

      <Input
        type="password"
        placeholder="New Password"
        onChange={(e) => setNewPassword(e.target.value)}
      />

      <Button
        variant="outline"
        onClick={() => updatePassword(currentPassword, newPassword)}
      >
        Update Password
      </Button>
      

      {message && (
        <p className="text-sm text-muted-foreground">{message}</p>
      )}
    </div>
  );
}

// "use client";

// import { Button } from "@/components/ui/button";
// import { Input } from "@/components/ui/input";
// import { DUMMY_PROFILE } from "@/mocks/profile.dummy";

// export default function ProfileUI() {
//   return (
//     <div className="mx-auto mt-20 max-w-md space-y-4">
//       <h1 className="text-xl font-semibold">My Profile</h1>

      
//       {!DUMMY_PROFILE.isVerified && (
//         <div className="rounded bg-yellow-100 p-3 text-sm">
//           Email belum terverifikasi
//           <Button size="sm" variant="link">
//             Kirim ulang verifikasi
//           </Button>
//         </div>
//       )}

      
//       <Input
//         placeholder="Name"
//         defaultValue={DUMMY_PROFILE.name}
//       />

      
//       <Input
//         type="file"
//         accept=".jpg,.jpeg,.png,.gif"
//       />

//       <Button>
//         Update Profile
//       </Button>

      
//       <Input
//         placeholder="New Email"
//         defaultValue={DUMMY_PROFILE.email}
//       />

//       <Button variant="outline">
//         Update Email
//       </Button>

//       <p className="text-sm text-muted-foreground">
//         {DUMMY_PROFILE.message}
//       </p>
//     </div>
//   );
// }

