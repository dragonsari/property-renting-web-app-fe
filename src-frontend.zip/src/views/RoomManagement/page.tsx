// "use client";

// import RoomTable from "@/components/property/RoomTable";
// import RoomForm from "@/components/property/RoomForm";
// import { useState } from "react";

// export default function RoomManagementView({
//   propertyId,
// }: {
//   propertyId: number;
// }) {
//   const [refresh, setRefresh] = useState(0);

//   return (
//     <div className="p-6 space-y-6">
//       <h1 className="text-xl font-semibold">Manage Rooms</h1>

//       <RoomForm
//         propertyId={propertyId}
//         onSuccess={() => setRefresh((v) => v + 1)}
//       />

//       <RoomTable
//         propertyId={propertyId}
//         refreshKey={refresh}
//       />
//     </div>
//   );
// }

"use client";

import RoomFormUI from "@/components/property/RoomForm";
import RoomTableUI from "@/components/property/RoomTable";

export default function RoomManagementUI() {
  return (
    <div className="p-6 space-y-6 mt-16">
      <h1 className="text-xl font-semibold">
        Manage Rooms
      </h1>

      <RoomFormUI />
      <RoomTableUI />
    </div>
  );
}

