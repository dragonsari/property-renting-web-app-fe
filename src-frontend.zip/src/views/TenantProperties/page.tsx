
"use client";

import Link from "next/link";
import { Button } from "@/components/ui/button";
import { useTenantProperties } from "@/hooks/useTenantProperties";
import PropertyTable from "@/components/property/PropertyTable";

export default function TenantPropertiesView() {
  const { data, loading, refetch } = useTenantProperties();

  if (loading) return <p>Loading...</p>;

  return (
    <div className="p-6 space-y-4">
      <div className="flex justify-between items-center">
        <h1 className="text-xl font-semibold">My Properties</h1>

        <Button asChild>
          <Link href="/tenant/properties/create">+ Add Property</Link>
        </Button>
      </div>

      <PropertyTable properties={data} onDeleted={refetch} />
    </div>
  );
}

// "use client";

// import Link from "next/link";
// import { Button } from "@/components/ui/button";
// import PropertyTableUI from "@/components/property/PropertyTable";
// import { DUMMY_TENANT_PROPERTIES } from "@/mocks/tenantProperties.dummy";

// export default function TenantPropertiesUI() {
//   return (
//     <div className="p-6 space-y-4 mt-16">
//       <div className="flex justify-between items-center">
//         <h1 className="text-xl font-semibold">
//           My Properties
//         </h1>

//         <Button asChild>
//           <Link href="#">
//             + Add Property
//           </Link>
//         </Button>
//       </div>

//       <PropertyTableUI
//         properties={DUMMY_TENANT_PROPERTIES}
//       />
//     </div>
//   );
// }
