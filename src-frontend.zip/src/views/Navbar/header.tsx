// "use client"

// import Link from "next/link"
// import { Logo } from "@/components/logo"
// import { Menu, X } from "lucide-react"
// import { Button } from "@/components/ui/button"
// import React from "react"
// import { useAuthStore } from "@/stores/auth.store"


// export const HeroHeader = () => {
//   const {role, isVerified, logout} =useAuthStore();
//   const menuItems = [
//   { name: "Profile", href: "/profile" },
//   { name: "Reset-Password-Confirm", href: "/Reset-Password-Confirm" },
//   { name: "Property", href: "/Property" },
//   ...(isVerified 
//     ? [{name : "Profile", href : "/profile"}] 
//   : []),
    
//   ...(isVerified && role === "TENANT" 
//     ?[{name : "Dashboard", href : "/tenant"}] 
//   : []),
//   { name : "tenant" , href : "/tenant"}
// ]
//   const [menuState, setMenuState] = React.useState(false)

//   return (
//     <header className="relative z-50">
//       <nav
//         data-state={menuState && "active"}
//         className="fixed inset-x-0 top-0 z-50 border-b bg-background/70 backdrop-blur-3xl"
//       >
//         <div className="mx-auto max-w-6xl px-6">
//           <div className="flex items-center justify-between py-4">
            
//             <Link
//               href="/"
//               aria-label="home"
//               className="relative z-50 flex items-center gap-2"
//               onClick={() => setMenuState(false)}
//             >
//               <Logo />
//             </Link>

            
//             <div className="hidden items-center gap-8 lg:flex">
//               <ul className="flex items-center gap-6 text-sm">
//                 {menuItems.map((item) => (
//                   <li key={item.name}>
//                     <Link
//                       href={item.href}
//                       className="text-muted-foreground transition hover:text-foreground"
//                     >
//                       {item.name}
//                     </Link>
//                   </li>
//                 ))}
//               </ul>

//               <div className="flex items-center gap-3">
//                 <Button asChild variant="ghost" size="sm">
//                   <Link href="/login">Login</Link>
//                 </Button>

//                 <Button asChild size="sm">
//                   <Link href="/RegisterUser">Register</Link>
//                 </Button>
//               </div>
//             </div>

//             <button
//               onClick={() => setMenuState(!menuState)}
//               aria-label="Toggle Menu"
//               className="relative z-50 lg:hidden"
//             >
//               {menuState ? <X /> : <Menu />}
//             </button>
//           </div>

//           {menuState && (
//             <div className="lg:hidden">
//               <div className="mt-2 space-y-6 rounded-2xl border bg-background p-6 shadow-lg">
//                 <ul className="space-y-4">
//                   {menuItems.map((item) => (
//                     <li key={item.name}>
//                       <Link
//                         href={item.href}
//                         onClick={() => setMenuState(false)}
//                         className="block text-muted-foreground hover:text-foreground"
//                       >
//                         {item.name}
//                       </Link>
//                     </li>
//                   ))}
//                 </ul>

//                 <div className="flex flex-col gap-3">
//                   {isVerified
//                   ? (
//                   <Button onClick={logout} asChild>
//                     Logout
//                   </Button>)
//                   : 
//                   <>
//                   <Button asChild variant="outline">
//                     <Link href="/login">Login</Link>
//                   </Button>

//                   <Button asChild>
//                     <Link href="/RegisterUser">Register</Link>
//                   </Button>
//                   </>
//                   }

//                 </div>
//               </div>
//             </div>
//           )}
//         </div>
//       </nav>
//     </header>
//   )
// }
"use client"

import Link from "next/link"
import { Logo } from "@/components/logo"
import { Ghost, Menu, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import React from "react"
import { useAuthStore } from "@/stores/auth.store"
import { usePathname } from "next/navigation"

export const HeroHeader = () => {
  const { role, isVerified, logout } = useAuthStore()
  const pathname = usePathname()

  const [menuState, setMenuState] = React.useState(false)


  React.useEffect(() => {
    setMenuState(false)
  }, [pathname])

  const menuItems = [
    { name: "Property", href: "/Property" },
    { name: "verifyemail", href: "/verify-email" },
    { name: "Property/[id]", href: "/Property/2" },
    ...(isVerified ? [{ name: "Profile", href: "/profile" }] : []),
    { name: "Profile", href: "/profile" },
    ...(isVerified && role === "TENANT"
      ? [{ name: "Dashboard", href: "/tenant" }]
      : []),
    { name: "/tenant/properties", href: "/tenant/properties" },
    { name: "/tenant/properties/[id]", href: "/tenant/properties/1" },
    { name: "/rooms/[roomId]", href: "/tenant/rooms/1" },
  ]

  return (
    <header className="relative z-50">
      <nav
        className="fixed top-4 inset-x-0 z-50"
      >

        <div className="mx-auto max-w-6xl px-4">
          <div className="flex items-center justify-between rounded-full border bg-background/80 px-6 py-3 shadow-lg backdrop-blur-xl">
            
            
            <Link
              href="/"
              aria-label="home"
              className="flex items-center gap-2"
            >
              <Logo />
            </Link>

            
            <div className="hidden items-center gap-8 lg:flex">
              <ul className="flex items-center gap-6 text-sm">
                {menuItems.map((item) => (
                  <li key={item.name}>
                    <Link
                      href={item.href}
                      className="text-muted-foreground transition hover:text-foreground"
                    >
                      {item.name}
                    </Link>
                  </li>
                ))}
              </ul>

              <div className="flex items-center gap-3">
                {isVerified ? (
                  <Button size="sm" variant="outline" onClick={logout}>
                    Logout
                  </Button>
                ) : (
                  <>
                    <Button asChild size="sm" variant="ghost">
                      <Link href="/login/user">Login</Link>
                    </Button>
                    <Button asChild size="sm">
                      <Link href="/RegisterUser">Register</Link>
                    </Button>
                  </>
                )}
              </div>
            </div>


            <button
              onClick={() => setMenuState((prev) => !prev)}
              aria-label="Toggle Menu"
              className="lg:hidden"
            >
              {menuState ? <X /> : <Menu />}
            </button>
          </div>

          
          {menuState && (
            <div className="mt-3 lg:hidden">
              <div className="rounded-2xl border bg-background p-6 shadow-xl">
                <ul className="space-y-4">
                  {menuItems.map((item) => (
                    <li key={item.name}>
                      <Link
                        href={item.href}
                        onClick={() => setMenuState(false)}
                        className="block text-muted-foreground hover:text-foreground"
                      >
                        {item.name}
                      </Link>
                    </li>
                  ))}
                </ul>

                <div className="mt-6 flex flex-col gap-3">
                  {isVerified ? (
                    <Button
                      onClick={() => {
                        logout()
                        setMenuState(false)
                      }}
                    >
                      Logout
                    </Button>
                  ) : (
                    <>
                      <Button asChild variant="outline">
                        <Link href="/login/user">Login</Link>
                      </Button>
                      <Button asChild >
                        <Link href="/RegisterUser">Register</Link>
                      </Button>
                    </>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      </nav>
    </header>
  )
}
