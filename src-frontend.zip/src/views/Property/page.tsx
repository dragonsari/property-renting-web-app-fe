"use client";

import { usePropertyCatalog } from "@/hooks/usePropertyCatalog";
import PropertyCard from "@/components/property/PropertyCard";
import PropertyFilter from "@/components/property/PropertyFilter";
import PropertyPagination from "@/components/property/PropertyPagination";
import { PropertyQuery } from "@/services/propertyCatalog.service";

type Props = {
  query: PropertyQuery;
  onChange: (key: string, value: any) => void;
};

export default function Property({ query, onChange }: Props) {
  const { data, loading } = usePropertyCatalog(query);

  if (loading) return <p>Loading...</p>;

  return (
    <div className="p-6 space-y-6 mt-20">
      <PropertyFilter
        onChange={onChange}
        onSearch={(payload) => {
          onChange("latitude", payload.latitude);
          onChange("longitude", payload.longitude);
          onChange("page", 1); 
        }}
      />

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {data.data.map((item: any) => (
          <PropertyCard key={item.id} property={item} />
        ))}
      </div>

      <PropertyPagination
        page={data.pagination.page}
        totalPages={data.pagination.totalPages}
        onChange={(p) => onChange("page", p)}
      />
    </div>
  );
}

// "use client";

// import PropertyCard from "@/components/property/PropertyCard";
// import PropertyFilter from "@/components/property/PropertyFilter";
// import PropertyPagination from "@/components/property/PropertyPagination";
// import { DUMMY_PROPERTIES } from "@/mocks/property.mock";

// export default function Property() {
//   return (
//     <div className="p-6 space-y-6 mx-auto max-w-5xl">
//       <PropertyFilter />

//       <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
//         {DUMMY_PROPERTIES.map((item) => (
//           <PropertyCard key={item.id} property={item} />
//         ))}
//       </div>

//       <PropertyPagination currentPage={1} totalPages={1} />
//     </div>
//   );
// }
