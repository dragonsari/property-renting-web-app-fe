// "use client";

// import AvailabilityForm from "@/components/property/AvailabilityForm";
// import PeakRateForm from "@/components/property/PeakRateForm";
// import PeakRateTable from "@/components/property/PeakRateTable";

// export default function RoomCalendarView({
//   roomId,
// }: {
//   roomId: number;
// }) {
//   return (
//     <div className="p-6 space-y-6">
//       <h1 className="text-xl font-semibold">Room Availability & Peak Rate</h1>

//       <AvailabilityForm roomId={roomId} />

//       <PeakRateForm roomId={roomId} />

//       <PeakRateTable roomId={roomId} />
//     </div>
//   );
// }

"use client";

import AvailabilityFormUI from "@/components/property/AvailabilityForm";
import PeakRateFormUI from "@/components/property/PeakRateForm";
import PeakRateTableUI from "@/components/property/PeakRateTable";

export default function RoomCalendarUI() {
  return (
    <div className="p-6 space-y-6 mt-16">
      <h1 className="text-xl font-semibold">
        Room Availability & Peak Rate
      </h1>

      <AvailabilityFormUI />
      <PeakRateFormUI />
      <PeakRateTableUI />
    </div>
  );
}

